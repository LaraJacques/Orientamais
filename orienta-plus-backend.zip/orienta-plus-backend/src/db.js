const { Pool, types } = require('pg');
const config = require('./config');

// NUMERIC (oid 1700) volta como string por padrão; aqui os valores são pequenos e seguros como número.
types.setTypeParser(1700, (valor) => parseFloat(valor));

function criarPool(url = config.databaseUrl) {
  if (!url) {
    throw new Error('DATABASE_URL não definida. Copie .env.example para .env e preencha.');
  }
  return new Pool({
    connectionString: url,
    ssl: config.databaseSsl ? { rejectUnauthorized: false } : undefined,
    max: 10,
  });
}

module.exports = { criarPool };
